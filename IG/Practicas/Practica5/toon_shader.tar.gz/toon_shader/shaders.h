//**************************************************************************
// Ejemplo de vertex y fragment shaders
//
// Domingo Martin Perandres 2014
//
// GPL
//**************************************************************************

#ifndef SHADERS_H
#define SHADERS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <GL/glew.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glext.h>
#include <iostream>


#define GL_GLEXT_PROTOTYPES

using namespace std;

bool read_file(char *File, char *&Code);
int check_opengl_error();
void print_shader_info_log(GLuint Shader);
void print_program_info_log(GLuint Program);
int execute_shaders(string File_vertex_shader, string File_fragment_shader);
void activate_shaders();
void deactivate_shaders();

#endif // SHADERS_H
