//**************************************************************************
// Ejemplo de vertex y fragment shaders
//
// Domingo Martin Perandres 2014
//
// GPL
//**************************************************************************

#include "shaders.h"


GLuint Vertex_shader;
GLuint Fragment_shader;
GLuint Program;

//**************************************************************************
//
//***************************************************************************

bool read_file(char *File,char *&Code)
{
  FILE *File_pointer;
  int Count=0;

  if (File != NULL) {
    File_pointer = fopen(File,"rt");

    if (File_pointer != NULL) {

      fseek(File_pointer, 0, SEEK_END);
      Count = ftell(File_pointer);

      rewind(File_pointer);
      if (Count > 0) {
        Code = (char *)malloc(sizeof(char) * (Count+1));
        Count = fread(Code,sizeof(char),Count,File_pointer);
        Code[Count] = '\0';
      }
      fclose(File_pointer);
      return(true);
    }
    else return(false);
  }
  else return(false);
}


//**************************************************************************
// Returns 1 if an OpenGL error occurred, 0 otherwise.
//***************************************************************************

int check_opengl_error()
{
    GLenum glErr;
    int    retCode = 0;

    glErr = glGetError();
    while (glErr != GL_NO_ERROR)
    {
        printf("glError: %s\n",gluErrorString(glErr));
        retCode = 1;
        glErr = glGetError();
    }
    return retCode;
}

//**************************************************************************
// Muestra el log de un shader
//***************************************************************************

void print_shader_info_log(GLuint Shader)
{
    int Info_log_length = 0;
    int Characters_written  = 0;
    GLchar *Info_log;

    check_opengl_error();

    glGetShaderiv(Shader, GL_INFO_LOG_LENGTH, &Info_log_length);

    check_opengl_error();

    if (Info_log_length > 0)
    {
        Info_log = (GLchar *)malloc(Info_log_length);
        if (Info_log == NULL)
        {
            printf("ERROR: Could not allocate Info_log buffer\n");
            exit(1);
        }
        glGetShaderInfoLog(Shader, Info_log_length, &Characters_written, Info_log);
        if (Characters_written>0) printf("Shader Info_log:\n%s\n\n", Info_log);
        free(Info_log);
    }
    check_opengl_error();
}


//**************************************************************************
// Muestra el log de un programa
//***************************************************************************

void print_program_info_log(GLuint Program)
{
    int Info_log_length = 0;
    int Characters_written  = 0;
    GLchar *Info_log;

    check_opengl_error();

    glGetProgramiv(Program, GL_INFO_LOG_LENGTH, &Info_log_length);

    check_opengl_error();

    if (Info_log_length > 0)
    {
        Info_log = (GLchar *)malloc(Info_log_length);
        if (Info_log == NULL)
        {
            printf("ERROR: Could not allocate Info_log buffer\n");
            exit(1);
        }
        glGetProgramInfoLog(Program, Info_log_length, &Characters_written, Info_log);
        if (Characters_written>0) printf("Program Info_log:\n%s\n\n", Info_log);
        free(Info_log);
    }
    check_opengl_error();
}


//**************************************************************************
// lee, compila, enlaza y activa un programa a partir de uno o dos shaders
//***************************************************************************

int execute_shaders(string File_vertex_shader,string File_fragment_shader)
{
  // lectura del codigo de los shaders
  bool Vertex_shader_readed=false;
  bool Fragment_shader_readed=false;


  GLint  Vertices_shader_compiled, Fragment_shader_compiled;
  GLint  Shaders_compiled;

  // lectura de los ficheros
  char *Vertex_shader_code=NULL;
  char *Fragment_shader_code=NULL;

  Vertex_shader_readed=read_file((char *)File_vertex_shader.c_str(),Vertex_shader_code);
  Fragment_shader_readed=read_file((char *)File_fragment_shader.c_str(),Fragment_shader_code);

  if (Vertex_shader_readed==false && Fragment_shader_readed==false) return(-1);

  //cout << Vertex_shader_code << endl;
  //cout << Fragment_shader_code << endl;

  // 1 Crear los shaders
  if (Vertex_shader_readed==true) Vertex_shader=glCreateShader(GL_VERTEX_SHADER);
  if (Fragment_shader_readed==true) Fragment_shader=glCreateShader(GL_FRAGMENT_SHADER);

  // 2 Asigna el código fuente
  if (Vertex_shader_readed==true) glShaderSource(Vertex_shader,1,(const GLchar **) &Vertex_shader_code,NULL);
  if (Fragment_shader_readed==true) glShaderSource(Fragment_shader,1,(const GLchar **) &Fragment_shader_code,NULL);

  // Se libera la memoria del código
  if (Vertex_shader_readed==true) free(Vertex_shader_code);
  if (Fragment_shader_readed==true) free(Fragment_shader_code);

  // 3 Se compila el código
  if (Vertex_shader_readed==true){
    glCompileShader(Vertex_shader);
    // Comprobación
    check_opengl_error();
    glGetShaderiv(Vertex_shader, GL_COMPILE_STATUS, &Vertices_shader_compiled);
    print_shader_info_log(Vertex_shader);
    if (Vertices_shader_compiled==GL_FALSE){
      cout << "Error de compilacion en el vertex shader" << endl;
      return(-1);
    }
  }

  if (Fragment_shader_readed==true){
    glCompileShader(Fragment_shader);
    // Comprobación
    check_opengl_error();
    glGetShaderiv(Fragment_shader, GL_COMPILE_STATUS, &Fragment_shader_compiled);
    print_shader_info_log(Fragment_shader);
    if (Fragment_shader_compiled==GL_FALSE){
      cout << "Error de compilacion en el fragment shader" << endl;
      return(-1);
    }
  }

  // 4 Se crea el programa
  Program=glCreateProgram();

  // 5 Se asignan los shaders al programa
  if (Vertex_shader_readed==true) glAttachShader(Program,Vertex_shader);
  if (Fragment_shader_readed==true) glAttachShader(Program,Fragment_shader);

  // 6 Se enlaza el programa
  glLinkProgram(Program);
  // Comprobación
  check_opengl_error();
  glGetProgramiv(Program, GL_LINK_STATUS, &Shaders_compiled);
  print_program_info_log(Program);
  if (Shaders_compiled==GL_FALSE){
    cout << "Error de enlazado" << endl;
    return(-1);
  }

  // 7 Se activa el programa
  glUseProgram(Program);

  return(0);
}

//**************************************************************************
//
//***************************************************************************

void activate_shaders()
{
  glUseProgram(Program);
}

//**************************************************************************
//
//***************************************************************************

void deactivate_shaders()
{
  glUseProgram(0);
}
